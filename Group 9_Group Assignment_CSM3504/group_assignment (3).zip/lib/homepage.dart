import 'package:flutter/material.dart';
//import 'package:flutter/cupertino.dart';
//*void main() => runApp(const App());

import 'view/registrationFleet.dart';
import 'view/managerView.dart';
import 'view/staffAuthorization.dart';
import 'view/staffView.dart';
import 'view/staffViewWithAuthorization.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  MyHomePage createState() => MyHomePage();
}

class MyHomePage extends State {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //application name
      title: 'Group Assignment',
      theme: ThemeData(
          // primarySwatch: Color.fromARGB(255, 9, 233, 245),
          ),
      home: Scaffold(
        appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                );
              },
            ),
            //centerTitle: true,
            title: Text('Main Menu')),
        body: Container(
            alignment: Alignment.center,
            child: Column(children: <Widget>[
              Padding(padding: EdgeInsets.all(15)),
              Text('Welcome to Fleet App',
                  style: TextStyle(
                    fontSize: 25.0,
                  )),
              Text('by Group 9',
                  style: TextStyle(
                    fontSize: 25.0,
                  )),
              Padding(padding: EdgeInsets.all(15)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => RegistrationFleet()));
                },
                child: Text('Register New Fleet'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
              Padding(padding: EdgeInsets.all(15)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ManagerView()));
                },
                child: Text('List of Fleet(Manager View)'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
              Padding(padding: EdgeInsets.all(15)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: ((context) => StaffAuthorization())));
                },
                child: Text('Staff Authorization by Manager'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
              Padding(padding: EdgeInsets.all(15)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => StaffView()));
                },
                child: Text('List of Fleet(Staff View)'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
              Padding(padding: EdgeInsets.all(15)),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => StaffViewWithAuthorization()));
                },
                child: Text('List of Fleet(Authorized Staff View)'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ),
            ])),
      ),
    );
  }
}
