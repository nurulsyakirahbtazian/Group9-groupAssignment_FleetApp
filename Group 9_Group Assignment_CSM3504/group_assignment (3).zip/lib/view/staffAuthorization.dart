//staffAuhorization.dart
//page where manager can allow or disallow staff to make change to status of fleet
//in the list of fleet

import 'package:flutter/material.dart';
import 'package:group_assignment/homepage.dart';
////void main() => runApp(const StaffAuthorization());

// void main() {
//   runApp(MaterialApp(
//     home: StaffAuthorization(),
//   ));
// }

class StaffAuthorization extends StatelessWidget {
  const StaffAuthorization({super.key});

  static const String _title = 'Staff Authorization';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(
                  context,
                  MaterialPageRoute(builder: (context) => Home()),
                );
              },
            ),
            title: const Text(_title)),
        body: const MyStatelessWidget(),
      ),
    );
  }
}

class CustomListItem extends StatelessWidget {
  const CustomListItem({
    super.key,
    //required this.thumbnail,
    required this.staffName,
  });

  //final Widget thumbnail;
  final String staffName;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
//             Expanded(
//               flex: 2,
//               child: thumbnail,
//             ),
            Expanded(
              flex: 3,
              child: FleetDescription(
                staffName: staffName,
              ),
            ),
//             const Icon(
//               Icons.more_vert,
//               size: 16.0,
//             ),
          ],
        ),
      ),
    );
  }
}

class FleetDescription extends StatefulWidget {
  const FleetDescription({
    required this.staffName,
  });

  final String staffName;

  @override
  FleetDescriptionState createState() => FleetDescriptionState();
}

class FleetDescriptionState extends State<FleetDescription> {
  bool _switchValue = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            widget.staffName,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14.0,
            ),
          ),
          const Padding(padding: EdgeInsets.symmetric(vertical: 2.0)),
          const Padding(padding: EdgeInsets.symmetric(vertical: 1.0)),
          Switch(
            value: _switchValue,
            onChanged: (bool value) {
              setState(() {
                _switchValue = value;
              });
            },
          ),
        ],
      ),
    );
  }
}

class MyStatelessWidget extends StatelessWidget {
  const MyStatelessWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(8.0),
      children: <Widget>[
        CustomListItem(
          staffName: 'Abu bin Jambu',
        ),
        CustomListItem(
          staffName: 'Lisa Perez',
        ),
        CustomListItem(
          staffName: 'Jung Jaemin',
        ),
      ],
    );
  }
}
