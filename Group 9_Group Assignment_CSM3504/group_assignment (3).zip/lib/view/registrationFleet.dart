//registrationFleet.dart
////page where staff and manager can register fleet

import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:group_assignment/firebase_options.dart';

enum FleetStatus { active, inactive }

//class InsertData extends StatefulWidget {
class RegistrationFleet extends StatefulWidget {
  RegistrationFleet({Key? key}) : super(key: key);

  @override
  _RegistrationFleetState createState() => _RegistrationFleetState();

  final databaseReference = FirebaseDatabase.instance.reference();
}

class _RegistrationFleetState extends State<RegistrationFleet> {
  FleetStatus? _status = FleetStatus.active;
  final _fleetNoController = TextEditingController();
  final _fleetNameController = TextEditingController();
  final _registrationDateController = TextEditingController();
  final _fleetLocationController = TextEditingController();

  late DatabaseReference dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref().child('FleetList');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Register New Fleet'),
        ),
        body: Padding(
            padding: EdgeInsets.all(15),
            child: Column(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextField(
                    controller: _fleetNoController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Fleet No',
                      hintText: 'Enter Fleet No',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextField(
                    controller: _fleetNameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Fleet Name',
                      hintText: 'Enter Fleet Name',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextField(
                    controller: _registrationDateController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Date Registration',
                      hintText: 'dd-MM-yyyy',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextField(
                    controller: _fleetLocationController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Fleet Location',
                      hintText: 'Enter Fleet Location',
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'Fleet Status',
                    textAlign: TextAlign.left,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(
                    children: <Widget>[
                      RadioListTile<FleetStatus>(
                        title: const Text('Active'),
                        value: FleetStatus.active,
                        groupValue: _status,
                        onChanged: (FleetStatus? value) {
                          setState(() {
                            _status = value;
                          });
                        },
                      ),
                      RadioListTile<FleetStatus>(
                        title: const Text('Inactive'),
                        value: FleetStatus.inactive,
                        groupValue: _status,
                        onChanged: (FleetStatus? value) {
                          setState(() {
                            _status = value;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                ElevatedButton(
                  child: const Text('Register'),
                  onPressed: () {
                    Map<String, String> fleets = {
                      'fleetno': _fleetNoController.text,
                      'fleetname': _fleetNameController.text,
                      'registrationdate': _registrationDateController.text,
                      'fleetlocation': _fleetLocationController.text,
                      'fleetstatus': _status.toString()
                    };
                    dbRef.push().set(fleets);
                    // createRecord();
                    //
                    _showDialog(context);
                  },
                ),
              ],
            )));
  }

  void _showDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Success!!"),
          content: new Text("Data is saved!"),
          actions: <Widget>[
            new ElevatedButton(
              child: new Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
