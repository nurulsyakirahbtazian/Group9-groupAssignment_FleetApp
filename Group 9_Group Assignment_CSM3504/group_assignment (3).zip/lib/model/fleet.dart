class Fleet {
final String fleetNo;
final String fleetName;
final int dateRegistered;
final String fleetLocation;
final String fleetStatus;
final bool isActive;

Fleet({
required this.fleetNo,
required this.fleetName,
required this.dateRegistered,
required this.fleetLocation,
required this.fleetStatus,
this.isActive = false,
});
}